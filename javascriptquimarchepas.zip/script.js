const apikey = "e9993a5d";
const url = `http://www.omdbapi.com/`;
const searchButton = document.getElementById('search-button');
const searchInput = document.getElementById('search-text');
const moviesGrid = document.getElementById('movies-grid');

searchButton.onclick = function() {
    event.preventDefault();
    const searchTerm = searchInput.value;
    if (searchTerm) {
        getMovies(searchTerm);
    }
};

function getMovies(search) {
    console.log(`Query : ${url}?apikey=${apikey}&s=${search}`);
    fetch(`${url}?apikey=${apikey}&s=${search}`)
        .then(res => res.json())
        .then(async data => {
            if (data.Response === "True") {
                await fillGrid(data.Search);
            } else {
                document.getElementById('movies-grid').innerHTML = 
                    "<p>No movie found</p>";
            }
        })
        .catch(error => {
            console.error('Error:', error);
            document.getElementById('movies-grid').innerHTML = 
                "<p>An error has ocurred</p>";
        });
}

function getMovieByID(id){
    return fetch(`${url}?apikey=${apikey}&i=${id}`).then(res => res.json()).then(data => {
        if (data.Response === "True") {
            return data;
        } else {
            throw new Error('Movie not found');
        }
    });
}

async function fillGrid(movies) {
    moviesGrid.innerHTML = ''; // On vide la grille avant d'ajouter les nouveaux films
    movies.forEach(async element => {
        console.log(`Element:`, element);
        moviesGrid.innerHTML += `
            <div class="movie-card" id="${element.imdbID}">
            </div>`;
        await fillGridDetails(element.imdbID);
    });
}

async function fillGridDetails(movieID){
    const movieCard = document.getElementById(movieID);
    movieCard.innerHTML = ''; // On vide la card avant d'ajouter les détails
    const element = await getMovieByID(movieID);
    // console.log(element);
    movieCard.innerHTML = `
        <div class="movie-card id="${element.imdbID}">
            <img src="${element.Poster !== "N/A" ? element.Poster : './placeholder.jpg'}" alt="${element.Title}">
            <h3 class="movie-info">${element.Title}</h3>
            <p class="movie-year">${element.Year}</p>
            <p class="movie-plot">${element.Plot}</p>
            <p class="movie-rating">IMDB Rating: ${element.Ratings.find(rating => rating.Source === "Internet Movie Database")?.Value || "N/A"}</p>
        </div>
    `;
}